# taaf-plain-checkpoint8

- Base: the exact author-shared plain TAAF bundle used by the two
  `g4run-taaf-plain-*` replicas (`ARC3-Inference` aa69123 dirty snapshot and
  `tufa-arc-agi-framework` fe9f7c4).
- Single mechanism: execute at most eight actions from one `action(...)`
  request, then return the settled board, checkpoint metadata, and the
  unexecuted suffix to TAAF's existing Python REPL.
- Existing terminal, game-over, level-completion, invalid-action, and timeout
  stops retain priority.
- Deliberately absent: ffa7gn, no-impact memory, state graph, animation memory,
  failed-prefix guard, hypothesis lease, plan reset, and prompt rewrites.

This is the inverse graft: pristine TAAF plus cap-8, not the ffa7gn cap-8
harness plus selected TAAF features.
